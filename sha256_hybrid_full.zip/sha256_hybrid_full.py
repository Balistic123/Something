#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sha256_hybrid_full.py
Comprehensive SHA-256 reduced‑round research harness (Windows-friendly).

Phases implemented (A–H):
 A) Bulk SMT sampling (Z3)
 B) Automatic anomaly re‑tests
 C) Cross‑solver trials (SMT‑LIB export + external solvers)
 D) Differential experiments (forward reduced‑round SHA‑256)
 E) ML anomaly detection (IsolationForest)
 F) Algebraic probe (linearized rank + tiny ANF demo via sympy)
 G) Loop orchestration, checkpointing, CSV/JSON logs, plots
 H) Solver internals capture (Z3 statistics)
"""

import os, sys, time, json, csv, argparse, datetime, random, subprocess, traceback
from pathlib import Path
from typing import Dict, Any, List, Tuple

try: import numpy as np
except: np = None
try: import pandas as pd
except: pd = None
try:
    from sklearn.ensemble import IsolationForest
except: IsolationForest = None
try:
    import matplotlib.pyplot as plt
    HAVE_MPL = True
except: HAVE_MPL = False
try:
    import sympy as sp
except: sp = None

try:
    from z3 import *
except Exception:
    print("z3-solver not found. Install: pip install z3-solver")
    sys.exit(1)

def nowstamp():
    return datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%d_%H%M%S")

def ensure_dir(p): os.makedirs(p, exist_ok=True); return p

def save_json(path, obj):
    ensure_dir(os.path.dirname(path) or ".")
    with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, indent=2)

def append_csv(path, rows):
    if not rows: return
    ensure_dir(os.path.dirname(path) or ".")
    hdr = list(rows[0].keys())
    write_header = not os.path.exists(path)
    with open(path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=hdr, extrasaction="ignore")
        if write_header: w.writeheader()
        for r in rows:
            if isinstance(r.get("anchors"), dict):
                r["anchors"] = ";".join(f"{k}={hex(v)}" for k,v in r["anchors"].items())
            w.writerow(r)

def parse_anchor_set(s: str) -> Dict[int,int]:
    out = {}
    if not s or s.strip().lower() in ("none","null","empty"): return out
    s = s.strip().replace("\"","").replace("'","")
    for kv in s.split(","):
        if "=" not in kv: continue
        k,v = kv.split("=",1)
        try: k = int(k.strip(), 0)
        except: k = int("".join(ch for ch in k if ch.isdigit()))
        try: v = int(v.strip(), 0)
        except: v = int(str(v).strip().replace(" ",""), 0)
        out[int(k)] = int(v)
    return out

def parse_anchor_sets(spec: str):
    if not spec: return [{}]
    out = []
    for chunk in spec.split(";"):
        c = chunk.strip().replace("\"","").replace("'","")
        if not c or c.lower() in ("none","null"): out.append({})
        else: out.append(parse_anchor_set(c))
    return out

def anchor_label(anchors: Dict[int,int]) -> str:
    if not anchors: return "anchors_none"
    parts = [f"{int(k)}={hex(int(anchors[k]))}" for k in sorted(anchors.keys(), key=lambda x:int(x))]
    return "anchors_" + "_".join(p.replace("0x","").replace("=","_") for p in parts)

K = [
0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

def ror(x, r): return ((x >> r) | ((x << (32-r)) & 0xffffffff)) & 0xffffffff
def shr(x, n): return (x >> n) & 0xffffffff
def Sigma0_f(x): return ror(x,2) ^ ror(x,13) ^ ror(x,22)
def Sigma1_f(x): return ror(x,6) ^ ror(x,11) ^ ror(x,25)
def sigma0_f(x): return ror(x,7) ^ ror(x,18) ^ shr(x,3)
def sigma1_f(x): return ror(x,17) ^ ror(x,19) ^ shr(x,10)
def Ch_f(x,y,z): return (x & y) ^ (~x & z)
def Maj_f(x,y,z): return (x & y) ^ (x & z) ^ (y & z)

def sha256_reduced_forward(M16, rounds):
    assert len(M16) >= 16
    W = list(M16[:16]) + [0]*max(0, rounds-16)
    for i in range(16, rounds):
        W[i] = (sigma1_f(W[i-2]) + W[i-7] + sigma0_f(W[i-15]) + W[i-16]) & 0xffffffff
    a,b,c,d,e,f,g,h = IV[:]
    for i in range(rounds):
        t1 = (h + Sigma1_f(e) + Ch_f(e,f,g) + K[i] + W[i]) & 0xffffffff
        t2 = (Sigma0_f(a) + Maj_f(a,b,c)) & 0xffffffff
        h,g,f,e,d,c,b,a = g,f,e,(d + t1) & 0xffffffff,c,b,a,(t1 + t2) & 0xffffffff
    outs = [ (IV[i] + v) & 0xffffffff for i,v in enumerate([a,b,c,d,e,f,g,h]) ]
    return outs

def build_z3_model(rounds, partial_words, anchors):
    s = Solver()
    M = [BitVec(f"M{i}",32) for i in range(16)]
    for k,v in anchors.items():
        if 0 <= k < 16: s.add(M[k] == v)
    W = M + [BitVec(f"W{i}",32) for i in range(16, rounds)]
    for i in range(16, rounds):
        s.add(W[i] == (RotateRight(W[i-2],17) ^ RotateRight(W[i-2],19) ^ LShR(W[i-2],10)
                       + W[i-7] + (RotateRight(W[i-15],7) ^ RotateRight(W[i-15],18) ^ LShR(W[i-15],3)) + W[i-16]) & BitVecVal(0xffffffff,32))
    a,b,c,d,e,f,g,h = [BitVecVal(x,32) for x in IV]
    for i in range(rounds):
        t1 = (h + (RotateRight(e,6)^RotateRight(e,11)^RotateRight(e,25)) + ((e & f) ^ (~e & g)) + BitVecVal(K[i],32) + W[i]) & BitVecVal(0xffffffff,32)
        t2 = ((RotateRight(a,2)^RotateRight(a,13)^RotateRight(a,22)) + ((a & b) ^ (a & c) ^ (b & c))) & BitVecVal(0xffffffff,32)
        h,g,f,e,d,c,b,a = g,f,e,(d+t1) & BitVecVal(0xffffffff,32), c,b,a,(t1+t2) & BitVecVal(0xffffffff,32)
    outs = [(BitVecVal(IV[i],32)+v) & BitVecVal(0xffffffff,32) for i,v in enumerate([a,b,c,d,e,f,g,h])]
    masks = [0xffffffff]*(8-partial_words) + [0]*partial_words
    for i in range(8):
        if masks[i] != 0xffffffff:
            s.add((outs[i] & BitVecVal(masks[i],32)) == BitVecVal(0,32))
    return s, M, outs

def z3_stats_dict(s):
    try:
        st = s.statistics()
        return { st.key(i): st.value(i) for i in range(len(st)) }
    except Exception:
        return {}

def run_z3_once(rounds, timeout_ms, pw, anchors, tag):
    s, M, outs = build_z3_model(rounds, pw, anchors)
    s.set("timeout", timeout_ms)
    t0 = time.time()
    res = s.check()
    elapsed = time.time() - t0
    meta = {"time_utc": nowstamp(), "rounds": rounds, "timeout_ms": timeout_ms, "partial_words": pw,
            "anchors": anchors, "z3_result": str(res), "elapsed_s": round(elapsed,6), "tag": tag}
    meta.update({ f"z3_{k}": v for k,v in z3_stats_dict(s).items() })
    if res == sat:
        try:
            mdl = s.model()
            meta["message_words"] = [int(mdl.eval(M[i], model_completion=True).as_long()) for i in range(16)]
        except Exception: pass
    return meta

def phaseA_bulk_sampling(cfg, anchors, outdir:Path):
    ensure_dir(outdir)
    rows = []
    for r in range(cfg["start"], cfg["max"]+1, cfg["step"]):
        for i in range(cfg["samples_per_round"]):
            tag = f"A_r{r}_s{i}"
            try: rows.append(run_z3_once(r, cfg["timeout_ms"], cfg["pw"], anchors, tag))
            except Exception as e: rows.append({"time_utc": nowstamp(), "rounds": r, "anchors": anchors, "z3_result": "error", "error": str(e)})
            if cfg.get("throttle_s"): time.sleep(cfg["throttle_s"])
    append_csv(str(outdir/"runs.csv"), rows)
    save_json(str(outdir/"meta.json"), {"generated": nowstamp(), "rows": len(rows), "cfg": cfg, "anchors": anchors})
    return rows

def phaseB_pick_targets(runs_csv:Path, top_rounds:int=3):
    if pd is None or not runs_csv.exists(): return []
    df = pd.read_csv(str(runs_csv))
    if "elapsed_s" not in df.columns: return []
    med = df.groupby("rounds")["elapsed_s"].median().rename("round_med").reset_index()
    df = df.merge(med, on="rounds", how="left")
    df["time_bias"] = df["elapsed_s"] - df["round_med"]
    picks = df.groupby("rounds")["time_bias"].median().abs().sort_values(ascending=False).head(top_rounds).index.tolist()
    return [("timebias", int(r)) for r in picks]

def phaseB_retest(cfg, anchors, targets, outdir:Path):
    ensure_dir(outdir)
    rows = []
    for reason, r in targets:
        for i in range(cfg["retest_samples"]):
            tag = f"B_{reason}_r{r}_i{i}"
            rows.append(run_z3_once(r, cfg["retest_timeout_ms"], cfg["pw"], anchors, tag))
    append_csv(str(outdir/"retest_runs.csv"), rows)
    return rows

def export_smt2(solver): 
    try: return solver.to_smt2()
    except Exception:
        try:
            sexpr="(set-logic QF_BV)\n"
            for a in solver.assertions(): sexpr += f"(assert {a.sexpr()})\n"
            sexpr += "(check-sat)\n"; return sexpr
        except Exception: return ""

def call_external_solver(smt2_str, solver_cmd, timeout_ms):
    try:
        p = subprocess.Popen(solver_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True, text=True)
        out,err = p.communicate(smt2_str, timeout=timeout_ms/1000.0)
        return {"status":"ok","stdout":out,"stderr":err,"retcode":p.returncode}
    except subprocess.TimeoutExpired:
        return {"status":"timeout","stdout":"","stderr":"timeout","retcode":-1}
    except Exception as e:
        return {"status":"error","error":str(e),"retcode":-2}

def phaseC_cross(cfg, anchors, outdir:Path):
    ensure_dir(outdir)
    res = []
    rounds_list = cfg.get("cross_rounds", [cfg["start"], min(cfg["start"]+1, cfg["max"])])
    exts = cfg.get("external_solvers", ["cvc5 --lang smtlib2", "boolector -m"])
    for r in rounds_list:
        s,_,_ = build_z3_model(r, cfg["pw"], anchors)
        s.set("timeout", cfg["timeout_ms"])
        smt2 = export_smt2(s)
        for cmd in exts:
            out = call_external_solver(smt2, cmd, cfg["timeout_ms"])
            out.update({"rounds":r, "solver_cmd":cmd, "anchors":anchors})
            res.append(out)
    save_json(str(outdir/"cross_solver_results.json"), res)
    return res

def phaseD_differentials(cfg, anchors, outdir:Path):
    ensure_dir(outdir)
    if np is None:
        save_json(str(outdir/"diff_summary.json"), {"status":"skipped","reason":"numpy missing"})
        return []
    results = []
    for r in range(cfg["start"], cfg["max"]+1, cfg["step"]):
        flips = np.zeros((8,32), dtype=int)
        for _ in range(cfg["diff_samples"]):
            M = [random.getrandbits(32) for _ in range(16)]
            for k,v in anchors.items():
                if 0<=k<16: M[k]=v
            base = sha256_reduced_forward(M, r)
            w = cfg.get("diff_flip_word", 0)
            b = random.randrange(32)
            M2 = M[:]; M2[w] ^= (1<<b)
            alt = sha256_reduced_forward(M2, r)
            for wi in range(8):
                x = base[wi]^alt[wi]
                for bi in range(32):
                    if (x>>bi)&1: flips[wi,bi]+=1
        probs = flips.astype(float)/max(1,cfg["diff_samples"])
        import numpy as _np
        _np.savetxt(str(outdir/f"diff_probs_r{r}.csv"), probs, delimiter=",", fmt="%.6f")
        results.append({"rounds":r, "flip_word": cfg.get("diff_flip_word",0), "samples": cfg["diff_samples"]})
    save_json(str(outdir/"diff_summary.json"), results)
    return results

def phaseE_ml(csv_path:Path, outdir:Path):
    ensure_dir(outdir)
    if IsolationForest is None or pd is None or np is None:
        return {"status":"skipped","reason":"deps missing"}
    if not csv_path.exists():
        return {"status":"skipped","reason":"no csv"}
    df = pd.read_csv(str(csv_path))
    if len(df) < 50:
        return {"status":"skipped","reason":"too few rows"}
    feats = df[["elapsed_s","rounds"]].fillna(0).values
    iso = IsolationForest(random_state=42, contamination=0.02)
    y = iso.fit_predict(feats)
    df["anomaly"] = (y==-1)
    outp = outdir/"ml_anomalies.csv"
    df[df["anomaly"]].to_csv(outp, index=False)
    return {"status":"ok","count": int(df['anomaly'].sum()), "out": str(outp)}

def linearized_rank_upper(rounds:int, anchors:Dict[int,int]) -> Dict[str,int]:
    total_bits = 16*32
    anchored = sum(32 for k in anchors.keys() if 0<=k<16)
    free_bits = max(0, total_bits-anchored)
    return {"linearized_varcount": total_bits, "anchored_bits": anchored, "free_bits": free_bits, "rank_upper_bound": free_bits}

def tiny_anf_demo(rounds:int=8) -> Dict[str,Any]:
    if sp is None:
        return {"status":"skipped","reason":"sympy not installed"}
    a,b = sp.symbols('a b')
    a1 = sp.Xor(a,b)  # toy XOR
    return {"status":"ok","example":"a1 = a XOR b (toy)", "expr_str": str(a1)}

def phaseF_algebra(cfg, anchors, outdir:Path):
    ensure_dir(outdir)
    lin = linearized_rank_upper(cfg["start"], anchors)
    res = {"linearized": lin}
    try: res["anf_demo"] = tiny_anf_demo(min(8,cfg["start"]))
    except Exception as e: res["anf_demo"] = {"status":"error","error":str(e)}
    save_json(str(outdir/"linearized_probe.json"), res)
    return res

def run_cycle(cfg, anchors, out_root:Path):
    albl = anchor_label(anchors)
    base = out_root / albl
    ensure_dir(base)
    print(f"[A] bulk SMT sampling -> {base/'phaseA'}")
    phaseA_bulk_sampling(cfg, anchors, base/"phaseA")
    print("[E] ML anomaly detection")
    phaseE_ml(base/"phaseA"/"runs.csv", base/"phaseE")
    print("[D] differential forward experiments")
    phaseD_differentials(cfg, anchors, base/"phaseD")
    print("[C] cross-solver trials (best-effort)")
    phaseC_cross(cfg, anchors, base/"phaseC")
    print("[B] re-test anomalies")
    targets = phaseB_pick_targets(base/"phaseA"/"runs.csv", cfg.get("retest_top_rounds",3))
    if targets: phaseB_retest(cfg, anchors, targets, base/"phaseB")
    else: print("[B] no targets this cycle")
    print("[F] algebraic probe")
    phaseF_algebra(cfg, anchors, base/"phaseF")
    return True

def auto_loop(cfg, anchor_sets):
    out_root = Path(cfg["out_root"]); ensure_dir(out_root)
    loop = 0
    try:
        while cfg.get("max_loops",0)==0 or loop<cfg.get("max_loops",0):
            loop += 1
            print(f"[auto] start loop {loop} @ {nowstamp()}")
            for a in anchor_sets:
                try: run_cycle(cfg, a, out_root)
                except Exception as e:
                    print("[auto] exception:", e); traceback.print_exc()
            time.sleep(cfg.get("cooldown",2))
    except KeyboardInterrupt:
        print("[auto] Ctrl+C — graceful stop")
    finally:
        print("[auto] finished")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", default="auto")
    ap.add_argument("--anchorsets", default="none")
    ap.add_argument("--start", type=int, default=14)
    ap.add_argument("--step", type=int, default=1)
    ap.add_argument("--max", type=int, default=22)
    ap.add_argument("--pw", type=int, default=1)
    ap.add_argument("--timeout", type=int, default=60000)
    ap.add_argument("--samples_per_round", type=int, default=200)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--cooldown", type=int, default=2)
    ap.add_argument("--out_root", default="hybrid_full_run")
    ap.add_argument("--max_loops", type=int, default=0)
    ap.add_argument("--throttle_s", type=float, default=0.0)
    ap.add_argument("--retest_samples", type=int, default=1000)
    ap.add_argument("--retest_timeout_ms", type=int, default=300000)
    ap.add_argument("--retest_top_rounds", type=int, default=3)
    ap.add_argument("--diff_samples", type=int, default=2000)
    ap.add_argument("--diff_flip_word", type=int, default=0)
    ap.add_argument("--external_solvers", default="cvc5 --lang smtlib2;boolector -m")
    ap.add_argument("--cross_rounds", default="")
    args = ap.parse_args()

    cfg = {
        "start": args.start, "step": args.step, "max": args.max,
        "pw": args.pw, "timeout_ms": args.timeout, "samples_per_round": args.samples_per_round,
        "workers": args.workers, "cooldown": args.cooldown, "out_root": args.out_root,
        "max_loops": args.max_loops, "throttle_s": args.throttle_s,
        "retest_samples": args.retest_samples, "retest_timeout_ms": args.retest_timeout_ms,
        "retest_top_rounds": args.retest_top_rounds, "diff_samples": args.diff_samples,
        "diff_flip_word": args.diff_flip_word
    }
    if args.external_solvers:
        cfg["external_solvers"] = [s.strip() for s in args.external_solvers.split(";") if s.strip()]
    if args.cross_rounds:
        try:
            parts = [int(x) for x in args.cross_rounds.split(",") if x.strip()]
            if parts: cfg["cross_rounds"] = parts
        except: pass

    anchor_sets = parse_anchor_sets(args.anchorsets)
    print("Anchor sets:", anchor_sets)
    if args.mode == "auto":
        auto_loop(cfg, anchor_sets)
    else:
        out = Path(cfg["out_root"]); ensure_dir(out)
        for a in anchor_sets: run_cycle(cfg, a, out)

if __name__ == "__main__":
    main()
