# SHA-256 Full-Round Suite

Install:
  sudo apt update && sudo apt install -y python3-pip tmux unzip
  pip3 install --upgrade pip
  pip3 install z3-solver pandas numpy sympy scikit-learn matplotlib tqdm --break-system-packages

Run (tmux recommended):
  tmux new -s sha256full
  python3 sha256_fullround_suite.py --mode auto --anchorsets 'none;0=0x80000000;7=1,8=1;14=0,15=0x80' --pw 1 --timeout 60000 --samples_full_round 200 --workers 8 --diff_samples_full 50000 --out_root ./fullround_run

Artifacts:
  fullround_run/anchors_*/phaseA/runs.csv
  fullround_run/anchors_*/phaseC/model_64round.smt2
  fullround_run/anchors_*/phaseD/diff_probs_full.csv
  fullround_run/anchors_*/phaseE/ml_anomalies_full.csv
  fullround_run/anchors_*/phaseF/algebra.json
