#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# (short header omitted for brevity; identical to prior content)
import os, sys, time, json, csv, argparse, datetime, random, subprocess, traceback
from pathlib import Path
from typing import Dict, Any, List, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
try: import numpy as np
except: np = None
try: import pandas as pd
except: pd = None
try:
    from sklearn.ensemble import IsolationForest
except: IsolationForest = None
try: import sympy as sp
except: sp = None
try:
    from z3 import *
except Exception as e:
    print('ERROR: z3-solver missing. Install with: pip install z3-solver'); print('Exception:', e); sys.exit(1)

K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]
IV=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]

def nowstamp(): return datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S')
def ensure_dir(p): os.makedirs(p, exist_ok=True); return p
def save_json(path,obj): ensure_dir(os.path.dirname(path) or '.'); open(path,'w',encoding='utf-8').write(json.dumps(obj,indent=2))
def append_csv(path,rows):
    if not rows: return
    ensure_dir(os.path.dirname(path) or '.')
    hdr=list(rows[0].keys()); wh=not os.path.exists(path)
    with open(path,'a',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=hdr,extrasaction='ignore')
        if wh: w.writeheader()
        for r in rows:
            if isinstance(r.get('anchors'),dict):
                r['anchors']=';'.join(f"{k}={hex(v)}" for k,v in r['anchors'].items())
            w.writerow(r)

def ror(x,r): return ((x>>r)|((x<<(32-r))&0xffffffff))&0xffffffff
def shr(x,n): return (x>>n)&0xffffffff
def Sigma0_f(x): return ror(x,2)^ror(x,13)^ror(x,22)
def Sigma1_f(x): return ror(x,6)^ror(x,11)^ror(x,25)
def sigma0_f(x): return ror(x,7)^ror(x,18)^shr(x,3)
def sigma1_f(x): return ror(x,17)^ror(x,19)^shr(x,10)
def Ch_f(x,y,z): return (x&y)^(~x&z)
def Maj_f(x,y,z): return (x&y)^(x&z)^(y&z)

def sha256_forward(M):
    assert len(M)>=16
    W=M[:16]+[0]*48
    for i in range(16,64): W[i]=(sigma1_f(W[i-2])+W[i-7]+sigma0_f(W[i-15])+W[i-16])&0xffffffff
    a,b,c,d,e,f,g,h=IV[:]
    for i in range(64):
        t1=(h+Sigma1_f(e)+Ch_f(e,f,g)+K[i]+W[i])&0xffffffff
        t2=(Sigma0_f(a)+Maj_f(a,b,c))&0xffffffff
        h,g,f,e,d,c,b,a=g,f,e,(d+t1)&0xffffffff,c,b,a,(t1+t2)&0xffffffff
    return [ (IV[i]+v)&0xffffffff for i,v in enumerate([a,b,c,d,e,f,g,h]) ]

def build_model(partial_words,anchors):
    s=Solver(); M=[BitVec(f'M{i}',32) for i in range(16)]
    for k,v in anchors.items():
        if 0<=k<16: s.add(M[k]==v)
    W=M+[BitVec(f'W{i}',32) for i in range(16,64)]
    for i in range(16,64):
        s.add(W[i]==(RotateRight(W[i-2],17)^RotateRight(W[i-2],19)^LShR(W[i-2],10)+W[i-7]+(RotateRight(W[i-15],7)^RotateRight(W[i-15],18)^LShR(W[i-15],3))+W[i-16]) & BitVecVal(0xffffffff,32))
    a,b,c,d,e,f,g,h=[BitVecVal(x,32) for x in IV]
    for i in range(64):
        t1=(h+(RotateRight(e,6)^RotateRight(e,11)^RotateRight(e,25))+((e&f)^(~e&g))+BitVecVal(K[i],32)+W[i]) & BitVecVal(0xffffffff,32)
        t2=((RotateRight(a,2)^RotateRight(a,13)^RotateRight(a,22))+((a&b)^(a&c)^(b&c))) & BitVecVal(0xffffffff,32)
        h,g,f,e,d,c,b,a=g,f,e,(d+t1)&BitVecVal(0xffffffff,32),c,b,a,(t1+t2)&BitVecVal(0xffffffff,32)
    outs=[(BitVecVal(IV[i],32)+v)&BitVecVal(0xffffffff,32) for i,v in enumerate([a,b,c,d,e,f,g,h])]
    masks=[0xffffffff]*(8-partial_words)+[0]*partial_words
    for i in range(8):
        if masks[i]!=0xffffffff:
            s.add((outs[i]&BitVecVal(masks[i],32))==BitVecVal(0,32))
    return s,M,outs

def z3_stats_dict(s):
    try:
        st=s.statistics(); return {st.key(i):st.value(i) for i in range(len(st))}
    except: return {}

def run_z3(timeout_ms,pw,anchors,tag,scale=1.0):
    s,M,outs=build_model(pw,anchors); s.set('timeout',int(timeout_ms*scale))
    t0=time.time(); res=s.check(); el=time.time()-t0
    meta={'time_utc':nowstamp(),'rounds':64,'timeout_ms':int(timeout_ms*scale),'partial_words':pw,'anchors':anchors,'z3_result':str(res),'elapsed_s':round(el,6),'tag':tag}
    meta.update({f'z3_{k}':v for k,v in z3_stats_dict(s).items()})
    if res==sat:
        try:
            m=s.model(); meta['message_words']=[int(m.eval(M[i],model_completion=True).as_long()) for i in range(16)]
        except: pass
    return meta

def parse_anchor_set(s):
    out={}
    if not s or s.strip().lower() in ('none','null','empty'): return out
    s=s.strip().replace('"','').replace("'",'')
    for kv in s.split(','):
        if '=' not in kv: continue
        k,v=kv.split('=',1)
        try: k=int(k.strip(),0)
        except: k=int(''.join(ch for ch in k if ch.isdigit()))
        try: v=int(v.strip(),0)
        except: v=int(str(v).strip().replace(' ',''),0)
        out[int(k)]=int(v)
    return out

def parse_anchor_sets(spec):
    if not spec: return [{}]
    out=[]
    for chunk in spec.split(';'):
        c=chunk.strip().replace('"','').replace("'",'')
        if not c or c.lower() in ('none','null'): out.append({})
        else: out.append(parse_anchor_set(c))
    return out

def anchor_label(anchors):
    if not anchors: return 'anchors_none'
    parts=[f"{int(k)}={hex(int(anchors[k]))}" for k in sorted(anchors.keys(), key=lambda x:int(x))]
    return 'anchors_' + '_'.join(p.replace('0x','').replace('=','_') for p in parts)

def phaseA(cfg,anchors,outdir):
    ensure_dir(outdir); rows=[]; timeout=cfg['timeout_ms']; samples=cfg['samples_full_round']; workers=cfg['workers']; scale_max=cfg.get('timeout_scale_max',10.0)
    def task(i):
        scale=1.0+(scale_max-1.0)*(i%100)/100.0
        return run_z3(timeout,cfg['pw'],anchors,f'A_full_smt_s{i}',scale=scale)
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs=[ex.submit(task,i) for i in range(samples)]
        for f in as_completed(futs):
            rows.append(f.result())
            if len(rows)%50==0: append_csv(str(outdir/'runs.csv'), rows[-50:])
    append_csv(str(outdir/'runs.csv'), rows); save_json(str(outdir/'meta.json'), {'rows':len(rows),'cfg':cfg,'anchors':anchors}); return rows

def phaseB_pick(runs_csv,top=3):
    if pd is None or not Path(runs_csv).exists(): return []
    df=pd.read_csv(str(runs_csv)); 
    if 'elapsed_s' not in df.columns: return []
    med=df['elapsed_s'].median(); df['time_bias']=df['elapsed_s']-med
    picks=df.sort_values('time_bias',ascending=False).head(top).index.tolist()
    return [('timebias',64)]*len(picks)

def phaseB(cfg,anchors,targets,outdir):
    ensure_dir(outdir); rows=[]
    for reason,r in targets:
        for i in range(cfg['retest_samples_full']):
            rows.append(run_z3(cfg['retest_timeout_ms'],cfg['pw'],anchors,f'B_{reason}_r{r}_i{i}',scale=cfg.get('retest_timeout_scale',2.0)))
    append_csv(str(outdir/'retest_runs.csv'), rows); return rows

def export_smt2(solver):
    try: return solver.to_smt2()
    except:
        try:
            sexpr='(set-logic QF_BV)\n'
            for a in solver.assertions(): sexpr+=f'(assert {a.sexpr()})\n'
            sexpr+='(check-sat)\n'; return sexpr
        except: return ''

def phaseC(cfg,anchors,outdir):
    ensure_dir(outdir)
    s,_,_=build_model(cfg['pw'],anchors); s.set('timeout',cfg['timeout_ms'])
    smt2=export_smt2(s)
    open(outdir/'model_64round.smt2','w',encoding='utf-8').write(smt2)
    results=[]; 
    for cmd in cfg.get('external_solvers',['cvc5 --lang smtlib2','boolector -m']):
        try:
            p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True,text=True)
            out,err=p.communicate(smt2,timeout=cfg['timeout_ms']/1000.0)
            results.append({'cmd':cmd,'retcode':p.returncode,'stdout':out[-2000:],'stderr':err[-2000:]})
        except subprocess.TimeoutExpired:
            results.append({'cmd':cmd,'retcode':'timeout'})
        except Exception as e:
            results.append({'cmd':cmd,'error':str(e)})
    save_json(str(outdir/'cross_results.json'), results); return results

def phaseD(cfg,anchors,outdir):
    ensure_dir(outdir)
    if np is None: save_json(str(outdir/'diff_summary.json'), {'status':'skipped'}); return []
    N=cfg['diff_samples_full']; flips=np.zeros((8,32),dtype=np.int64)
    import random as _r
    for i in range(N):
        M=[_r.getrandbits(32) for _ in range(16)]
        for k,v in anchors.items():
            if 0<=k<16: M[k]=v
        base=sha256_forward(M)
        w=cfg.get('diff_flip_word',0); b=_r.randrange(32)
        M2=M[:]; M2[w]^=(1<<b)
        alt=sha256_forward(M2)
        for wi in range(8):
            x=base[wi]^alt[wi]
            for bi in range(32):
                if (x>>bi)&1: flips[wi,bi]+=1
        if (i+1)%5000==0:
            np.savetxt(str(Path(outdir)/'diff_probs_partial.csv'), flips/(i+1), delimiter=',', fmt='%.6f')
    probs=flips.astype(float)/max(1,N)
    np.savetxt(str(Path(outdir)/'diff_probs_full.csv'), probs, delimiter=',', fmt='%.6f')
    save_json(str(outdir/'diff_summary.json'), {'rounds':64,'samples':N}); return [{'rounds':64,'samples':N}]

def phaseE(csv_path,outdir):
    ensure_dir(outdir)
    if IsolationForest is None or pd is None or np is None or not Path(csv_path).exists(): return {'status':'skipped'}
    df=pd.read_csv(str(csv_path))
    if len(df)<50: return {'status':'skipped','reason':'few rows'}
    feats=df[['elapsed_s']].fillna(0).values
    iso=IsolationForest(random_state=42, contamination=0.02)
    y=iso.fit_predict(feats); df['anomaly']=(y==-1)
    outp=Path(outdir)/'ml_anomalies_full.csv'; df[df['anomaly']].to_csv(outp,index=False)
    return {'status':'ok','count':int(df['anomaly'].sum()),'out':str(outp)}

def linearized_rank_upper(anchors):
    total_bits=16*32; anchored=sum(32 for k in anchors.keys() if 0<=k<16); free=max(0,total_bits-anchored)
    return {'linearized_varcount': total_bits, 'anchored_bits': anchored, 'free_bits': free, 'rank_upper_bound': free}

def tiny_anf_demo():
    if sp is None: return {'status':'skipped'}
    a,b=sp.symbols('a b'); return {'status':'ok','expr':'a XOR b','repr':str(sp.Xor(a,b))}

def phaseF(cfg,anchors,outdir):
    ensure_dir(outdir); save_json(str(outdir/'algebra.json'), {'linearized':linearized_rank_upper(anchors),'anf_demo':tiny_anf_demo()}); return True

def run_cycle(cfg,anchors,out_root):
    albl=anchor_label(anchors); base=Path(out_root)/albl; ensure_dir(base)
    print(f"[A] full-round SMT -> {base/'phaseA'}"); phaseA(cfg,anchors,base/'phaseA')
    print('[E] ML'); phaseE(base/'phaseA'/'runs.csv', base/'phaseE')
    print('[D] diffs'); phaseD(cfg,anchors,base/'phaseD')
    print('[C] cross'); phaseC(cfg,anchors,base/'phaseC')
    print('[B] retests'); t=phaseB_pick(base/'phaseA'/'runs.csv', cfg.get('retest_top',3)); 
    if t: phaseB(cfg,anchors,t,base/'phaseB')
    else: print('[B] none')
    print('[F] algebra'); phaseF(cfg,anchors,base/'phaseF')
    return True

def auto_loop(cfg,anchor_sets):
    out_root=cfg['out_root']; loop=0
    try:
        while cfg.get('max_loops',0)==0 or loop<cfg.get('max_loops',0):
            loop+=1; print(f"[auto] start loop {loop} @ {nowstamp()}")
            for a in anchor_sets:
                try: run_cycle(cfg,a,out_root)
                except Exception as e: print('[auto] exception',e); traceback.print_exc()
            time.sleep(cfg.get('cooldown',2))
    except KeyboardInterrupt:
        print('[auto] stop')
    finally:
        print('[auto] finished')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--mode',default='auto')
    ap.add_argument('--anchorsets',default='none')
    ap.add_argument('--pw',type=int,default=1)
    ap.add_argument('--timeout',type=int,default=60000)
    ap.add_argument('--timeout_scale_max',type=float,default=10.0)
    ap.add_argument('--samples_full_round',type=int,default=200)
    ap.add_argument('--workers',type=int,default=8)
    ap.add_argument('--cooldown',type=int,default=2)
    ap.add_argument('--out_root',default='./fullround_run')
    ap.add_argument('--max_loops',type=int,default=0)
    ap.add_argument('--retest_samples_full',type=int,default=50)
    ap.add_argument('--retest_timeout_ms',type=int,default=300000)
    ap.add_argument('--retest_timeout_scale',type=float,default=2.0)
    ap.add_argument('--retest_top',type=int,default=3)
    ap.add_argument('--diff_samples_full',type=int,default=50000)
    ap.add_argument('--diff_flip_word',type=int,default=0)
    ap.add_argument('--external_solvers',default='cvc5 --lang smtlib2;boolector -m')
    args=ap.parse_args()
    cfg={'pw':args.pw,'timeout_ms':args.timeout,'timeout_scale_max':args.timeout_scale_max,'samples_full_round':args.samples_full_round,
         'workers':args.workers,'cooldown':args.cooldown,'out_root':args.out_root,'max_loops':args.max_loops,
         'retest_samples_full':args.retest_samples_full,'retest_timeout_ms':args.retest_timeout_ms,
         'retest_timeout_scale':args.retest_timeout_scale,'retest_top':args.retest_top,'diff_samples_full':args.diff_samples_full,
         'diff_flip_word':args.diff_flip_word,'external_solvers':[s.strip() for s in args.external_solvers.split(';') if s.strip()]}
    anchors=parse_anchor_sets(args.anchorsets)
    print('Anchor sets:', anchors)
    if args.mode=='auto': auto_loop(cfg,anchors)
    else:
        for a in anchors: run_cycle(cfg,a,cfg['out_root'])

if __name__=='__main__':
    main()
