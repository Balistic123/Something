#!/bin/bash
SESSION=sha256full
ARGS="--mode auto --anchorsets 'none;0=0x80000000;7=1,8=1;14=0,15=0x80' --pw 1 --timeout 60000 --samples_full_round 200 --workers 8 --diff_samples_full 50000 --out_root ./fullround_run"
tmux new-session -d -s $SESSION "python3 sha256_fullround_suite.py $ARGS > sha256_fullround.log 2>&1"
echo "Started tmux session $SESSION (log: sha256_fullround.log)"
